const baseUrl = "https://three-points.herokuapp.com/api/";
export const url = `${baseUrl}/`;
export const urlLogin = `${baseUrl}login`;
export const urlPosts = `${baseUrl}posts`;
